
# ChainART

An **OPENSOURCE** NonFungibleToken Project maded by two 15yrs teenagers from italy ;)

OpenaseaLINKS

- coming soon...

## HeadMasters

 - [@OttoBapotto](https://github.com/ottobapotto8)
 - [@Reyon20](https://github.com/reyon20)

![Logo](https://raw.githubusercontent.com/ottobapotto8/ChainArt/main/ChainArt/images/Main1.png)

## what do we want to do specifically

"Benvenuti in ChainArt, un progetto innovativo di NFT creato da due ragazzi di 15 anni. ChainArt si divide in tre progetti sottostanti: "LemonChain", "FishScale" e "SeaChain". LemonChain presenta una collezione unica di NFT di limoni, FishScale è dedicato alle lesche di pesce, mentre SeaChain offre un'esperienza immersiva con NFT del mare. Siamo entusiasti di condividere queste opere digitali con il mondo e siamo ansiosi di vedere come la community reagirà a questi progetti unici."

